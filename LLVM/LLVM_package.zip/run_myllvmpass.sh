#!/bin/sh

var1=$1
var2=$2
if [ "$#" -ne 2 ]
then
	echo "USAGE: ./run_myllvmpass.sh [INPUT BC FILE] [OUTPUT BC FILE]"
	exit 1
fi

opt -load ./build/Release+Asserts/lib/MyLLVMPass.so -MyLLVMPass < ${var1} > ${var2}

 